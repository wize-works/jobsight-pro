import InitializeDatabaseClient from "@/components/InitializeDatabaseClient"

export default function InitializeDatabasePage() {
    return <InitializeDatabaseClient />
}
