import IntegrationsSettingsClient from "@/components/IntegrationsSettingsClient"

export default function IntegrationsSettingsPage() {
    return <IntegrationsSettingsClient />
}
